import { CustomerNewComponent } from './customer-new/customer-new.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { CustomerAllComponent } from './customer-all/customer-all.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
   { path: '', redirectTo: 'customer', pathMatch: 'full' },
   { path: 'customer',  component: CustomerAllComponent },
   { path: 'add', component: CustomerNewComponent },
   { path: 'detail/:id', component: CustomerDetailsComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
